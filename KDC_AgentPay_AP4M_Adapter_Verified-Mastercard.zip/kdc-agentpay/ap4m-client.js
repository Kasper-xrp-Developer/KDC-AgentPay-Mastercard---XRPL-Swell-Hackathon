/** Configurable AP4M sandbox adapter. Paths and request bodies MUST be supplied from official docs. */
const BASE='https://hackathon.ap4m.build';
function path(value){if(!value||!/^\/[a-zA-Z0-9_./?=&-]+$/.test(value)||value.startsWith('//'))throw Error('Configure a valid AP4M endpoint path from the official API reference');return value;}
async function request(endpoint,{method='POST',body,token}={}){
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);
 try {const r=await fetch(BASE+path(endpoint),{method,headers:{'accept':'application/json',...(body?{'content-type':'application/json'}:{}),...(token?{'authorization':`Bearer ${token}`}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:controller.signal});
 const contentType=r.headers.get('content-type')||'';const data=contentType.includes('json')?await r.json():{message:(await r.text()).slice(0,500)};
 if(!r.ok)throw Error(`AP4M HTTP ${r.status}: ${JSON.stringify(data).slice(0,500)}`);return data;
 }finally{clearTimeout(timer)}
}
export async function authenticate(body){return request(process.env.AP4M_AUTH_PATH,{body});}
export async function createPayment(body,token){if(!token)throw Error('AP4M bearer token required');return request(process.env.AP4M_PAYMENT_PATH,{body,token});}
export async function getPaymentStatus(token,id){if(!token)throw Error('AP4M bearer token required');const template=process.env.AP4M_STATUS_PATH;if(!template||!template.includes('{id}'))throw Error('Configure AP4M_STATUS_PATH with {id}');return request(template.replace('{id}',encodeURIComponent(id)),{method:'GET',token});}
export const ap4mConfig=()=>({baseUrl:BASE,authConfigured:!!process.env.AP4M_AUTH_PATH,paymentConfigured:!!process.env.AP4M_PAYMENT_PATH,statusConfigured:!!process.env.AP4M_STATUS_PATH,reference:'https://hackathon.ap4m.build/docs/api-reference.md',verified:false});

# KDC AgentPay — Mastercard × XRPL hackathon starter

A runnable local dashboard and autonomous RLUSD payment engine for **XRPL Testnet**. It demonstrates no-per-payment-human-approval under a previously configured merchant allowlist and budget. **Mastercard AP4M is not integrated yet:** access to official API specification, credentials, and sandbox is required. Do not represent this as AP4M-certified or as a completed Mastercard payment.

## Start

1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `MERCHANT_ADDRESS` to a testnet XRPL account address you control.
4. Run `npm start` and open http://localhost:3000.
5. Click **Run agent**. By default this simulates a transaction (no on-chain settlement).

## On-chain Testnet demo

1. Generate a separate Testnet-only wallet, fund XRP from the XRPL faucet, and create RLUSD trust lines for both sender and receiver using the official Ripple tutorial: https://docs.ripple.com/products/stablecoin/developer-resources/rlusd-on-the-xrpl
2. Obtain Testnet RLUSD from the official tutorial's faucet link.
3. Set `XRPL_TESTNET_SEED` and `MERCHANT_ADDRESS` in `.env`; set `ENABLE_LIVE_TESTNET=true`.
4. Restart the server, run a payment, and inspect the transaction hash in a Testnet explorer.

## AP4M adapter integration checklist

- Obtain official Mastercard AP4M sandbox documentation, credentials and terms.
- Replace the scaffold payment-intent step with the actual authenticated AP4M request and its required metadata.
- Validate AP4M response signatures/status and map intent IDs to XRPL transaction hashes.
- Enforce budget and merchant restrictions in a durable, atomic datastore; this starter keeps them in memory only.
- Add idempotency persistence, reconciliation, rate limits, access controls, key custody, audit logs, and manual kill switch before any deployment.

## Limitations

Local demonstration only. In-memory state resets on restart. API is unauthenticated and must not be exposed to the public internet. No actual LLM planning (the autonomous decision is deterministic policy-based). No AP4M API call. No real-value payments; Testnet only. A single configured merchant is supported.

## AP4M API update (documentation access pending)

Base URL: `https://hackathon.ap4m.build`.
Official reference: https://hackathon.ap4m.build/docs/api-reference.md

The reference currently returned HTTP 401 to the build environment. To avoid inventing Mastercard endpoints or request schemas, `ap4m-client.js` supplies an HTTP adapter with configurable `AP4M_AUTH_PATH`, `AP4M_PAYMENT_PATH`, and `AP4M_STATUS_PATH` (`{id}` placeholder). Import `authenticate(body)`, `createPayment(body, token)`, and `getPaymentStatus(token, id)` from that module. All bearer requests use `Authorization: Bearer <token>`. Configure the precise paths and payloads after obtaining the API reference. The existing simulation and XRPL Testnet paths remain unchanged. **The adapter is not wired into the autonomous payment flow yet**; completing this requires verified API documentation.
